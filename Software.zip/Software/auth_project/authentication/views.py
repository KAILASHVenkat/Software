from django.shortcuts import render, redirect
from django.contrib.auth.hashers import check_password
from .models import User
from .forms import LoginForm, OTPForm
import random

# Temporary OTP storage (in a production system, store it in cache or DB)
otp_store = {}

def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']

            try:
                user = User.objects.get(email=email)
                if check_password(password, user.password):  # Ensure password is hashed in production
                    otp = str(random.randint(100000, 999999))
                    otp_store[email] = otp  # Store the OTP temporarily
                    return render(request, 'authentication/otp.html', {'email': email})
                else:
                    return render(request, 'authentication/login.html', {'form': form, 'error': 'Invalid credentials'})
            except User.DoesNotExist:
                return render(request, 'authentication/login.html', {'form': form, 'error': 'User does not exist'})
    else:
        form = LoginForm()
    return render(request, 'authentication/login.html', {'form': form})

def otp_view(request):
    if request.method == 'POST':
        form = OTPForm(request.POST)
        if form.is_valid():
            otp = form.cleaned_data['otp']
            email = request.POST['email']
            
            if otp_store.get(email) == otp:  # OTP matches
                user = User.objects.get(email=email)
                if user.role == 'student':
                    return redirect('student_page', email=email)
                elif user.role == 'faculty':
                    return redirect('faculty_page', email=email)
                elif user.role == 'admin':
                    return redirect('admin_page', email=email)
            else:
                return render(request, 'authentication/otp.html', {'form': form, 'error': 'Invalid OTP', 'email': email})
    else:
        form = OTPForm()
        email = request.GET['email']
    return render(request, 'authentication/otp.html', {'form': form, 'email': email})

def student_page(request, email):
    user = User.objects.get(email=email)
    return render(request, 'authentication/student.html', {'user': user})

def faculty_page(request, email):
    user = User.objects.get(email=email)
    return render(request, 'authentication/faculty.html', {'user': user})

def admin_page(request, email):
    user = User.objects.get(email=email)
    return render(request, 'authentication/admin.html', {'user': user})

