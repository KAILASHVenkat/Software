from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.login_view, name='login'),  # URL for the login page
    path('otp/', views.otp_view, name='otp'),  # URL for the OTP verification page
    path('student/<str:email>/', views.student_page, name='student_page'),  # URL for the student page
    path('faculty/<str:email>/', views.faculty_page, name='faculty_page'),  # URL for the faculty page
    path('admin/<str:email>/', views.admin_page, name='admin_page'),  # URL for the admin page
]
